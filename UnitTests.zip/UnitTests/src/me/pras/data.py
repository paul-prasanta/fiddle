'''
Created on Jun 18, 2016
@author: paul.prasanta
'''

def getNumbers( count ):
    if count % 2 == 0:
        nums = _even( count )
    else:
        nums = _odd( count )
    return nums

def _odd( count ):
    return [ x for x in xrange( count ) if x % 2 != 0 ]

def _even( count ):
    return [ x for x in xrange( count ) if x % 2 == 0 ]
