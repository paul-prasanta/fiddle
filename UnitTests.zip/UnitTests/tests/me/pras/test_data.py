'''
Created on Jun 18, 2016

@author: paul.prasanta
'''
import unittest
import me.pras.data as data


class Test(unittest.TestCase):

    def testData(self):
        count = 10
        expectedCount = count/2
        nums = data.getNumbers( count )
        self.assertEqual( len( nums ), expectedCount, 'Count mismatch...')

if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()